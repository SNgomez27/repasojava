package epsum.clasescamilo.ej5.clases;

public enum Estados {
    Encendido,
    Apagado
}